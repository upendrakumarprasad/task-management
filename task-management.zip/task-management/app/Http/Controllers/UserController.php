<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Session;

class UserController extends Controller {

    public function login() {
        return view('login');
    }

    public function signup() {
        return view('signup');
    }

    public function signin(Request $request) {
        if (!empty($request['email_id']) && !empty($request['password'])) {
            $User = User::where(['email' => $request['email_id'], 'password' => md5($request['password'])])->get()->first();
            if (empty($User->id)) {
                return response()->json(['status' => false, 'message' => 'Invalid user name and password']);
            }
            session()->put('signupAuth', $User);
            Session::save();
            return response()->json(['status' => true, 'message' => 'Successfully login', 'link' => url('/')]);
       
        }
    }

    public function create(Request $request) {

        if (!empty($request['json']) && is_array($request['json'])) {
            $json = $request['json'];
            $json['created_at'] = date('Y-m-d H:i:s');
            $json['email'] = !empty($json['email']) ? trim($json['email']) : '';
            $hasUser = User::where('email', '=', $json['email'])->get()->first();

            if (!empty($hasUser->email)) {
                return response()->json(['status' => false, 'message' => 'Email id is already registered, Please try to login']);
            }
            $json['password'] = md5($json['password']);
            $userData = User::create($json);
            session()->put('signupAuth', $userData);
            Session::save();
            return response()->json(['status' => true, 'message' => 'Successfully registred', 'link_web' => url('/')]);
        }
    }

    public function logout() {
        session()->forget('signupAuth');
        Session::save();
        return redirect(url('/login'));
    }

}
