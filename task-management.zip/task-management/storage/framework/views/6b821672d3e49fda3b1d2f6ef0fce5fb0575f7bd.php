<?php $__env->startSection('title', 'Sing-up'); ?>
<?php $__env->startSection('content'); ?>
<div id="page">
    <div class="content">
        <section class="wd100 section __signwrap">
            <div class="container">
                <div class="__signInerPG">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 login_box">
                            <span class="color-success"> </span>

                            <h4>Welcome back!</h4>
                            <h3>Create an account</h3>
                            <h6>Already have an account? <a href="<?php echo e(url('login')); ?>">Sign In</a></h6>



                            <form method="post" onsubmit="return false;">

                                <div class="__chkjSwch wd100">
                                    <label style="text-align: center;" class="form-check-label" for="inlineRadio2">Task Management Sign-up</label>
                                </div>
                                <div class="mb-3" id="email_login">
                                    <label for="exampleInputEmail1" id="labelHeading">Full Name</label><span class="required">*</span>
                                    <input type="text" class="form-control" required aria-describedby="Name" id="name">
                                </div>
                                <div class="mb-3" id="email_login">
                                    <label for="exampleInputEmail1" id="labelHeading">Email Id</label><span class="required">*</span>
                                    <input type="email" class="form-control" required name="username" aria-describedby="Name" id="email">
                                </div>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-3">
                                    <label>Phone Number</label><span class="required">*</span>
                                    <div class="__telcoddro"> 
                                        <div class="__codrop">
                                            <select class="form-select" name="countryCode" id="mobile_code">
                                                <option value="971">+971</option>
                                            </select>
                                        </div>
                                        <div class="__telrop">
                                            <input class="form-control maxlength" maxlength="9" type="number" id="mobile_number" placeholder="772000111">
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-2">
                                    <label for="exampleInputEmail1">Password</label><span class="required">*</span>
                                    <input type="password" name="password" required class="form-control" aria-describedby="Name" id="password" autocomplete="off">
                                </div>
                                <div class="mb-2">
                                    <label for="exampleInputEmail1">Confirm Password</label><span class="required">*</span>
                                    <input type="password" name="password" required class="form-control" aria-describedby="Name" id="cpassword" autocomplete="off">
                                </div>




                                <div class="mb-3 text-center">
                                    <button type="button" onclick="signup();" class="btn btn-primary  __ctm_btn border-radius-0 login_submit">Register <spinnerloader></spinnerloader></button>
                                </div>
                            </form>



                        </div>


                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    function signup() {
      
        if ($('#name').val() == "") {
            $('#name').css('border-color', 'red');
            $('#name').focus();
            return false;
        } else {
            $('#name').css('border-color', '');
        }

        if (!validateEmail($('#email').val()) || $('#email').val() == "") {
            $('#email').css('border-color', 'red');
            $('#email').focus();
            return false;
        } else {
            $('#email').css('border-color', '');
        }
        if ($('#mobile_number').val() == "") {
            $('#mobile_number').css('border-color', 'red');
            $('#mobile_number').focus();
            return false;
        } else {
            $('#mobile_number').css('border-color', '');
        }



     
        if ($('#password').val() == "") {
            $('#password').css('border-color', 'red');
            $('#password').focus();
            return false;
        } else {
            $('#password').css('border-color', '');
        }
        if ($('#cpassword').val() == "") {
            $('#cpassword').css('border-color', 'red');
            $('#cpassword').focus();
            return false;
        } else {
            $('#cpassword').css('border-color', '');
        }
        if ($('#password').val() != $('#cpassword').val()) {
            $('#password').css('border-color', 'red');
            $('#password').focus();
            alertSimple("Password are not matching");
            return false;
        } else {
            $('#password').css('border-color', '');
        }

        var form = new FormData();
        form.append('_token', CSRF_TOKEN);
        form.append('json[name]', $("#name").val());
        form.append('json[email]', $("#email").val());
        form.append('json[phone]', $("#mobile_code").val()+$("#mobile_number").val());
        form.append('json[password]', $("#password").val());
        $('spinnerLoader').html('<i class="fas fa-spinner fa-spin"></i>');
        setTimeout(function () {
            kb();
        }, 500);
        function kb() {
            var json = ajaxpost(form, "/sign-up");
            $('spinnerLoader').html('');
            try {
                json = jQuery.parseJSON(json);
                 alertSimple(json.message, json.status);
                if (json.status == true) {
                    setTimeout(function (){
                        window.location = json.link_web;
                    },800);
                } else {
                  
                }
            } catch (e) {
                alert(e);
            }
        }
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.4\htdocs\task-management\resources\views/signup.blade.php ENDPATH**/ ?>