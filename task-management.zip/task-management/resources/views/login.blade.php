@extends('layouts.app')
@section('title', 'Login')
@section('content')
<div id="page">
    <div class="content">
        <section class="wd100 section __signwrap">
            <div class="container">
                <div class="__signInerPG">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 login_box">
                            <span class="color-success"> </span>

                            <h4>Welcome back!</h4>
                            <h3>Sign in to your account</h3>
                            <h6>Not registered yet? <a href="{{url('/sign-up')}}">Sign Up</a></h6>



                            <form method="post" onsubmit="return false;">

                                <div class="__chkjSwch wd100">
                                    <label style="text-align: center;" class="form-check-label" for="inlineRadio2">Task Management Login</label>
                                </div>
                                <div class="mb-3" id="email_login">
                                    <label for="exampleInputEmail1" id="labelHeading">Email Id</label><span class="required">*</span>
                                    <input type="email" class="form-control" required name="username" aria-describedby="Name" id="email_id">
                                </div>

                                <div class="mb-2">
                                    <label for="exampleInputEmail1">Password</label><span class="required">*</span>
                                    <input type="password" name="password" required class="form-control" aria-describedby="Name" id="password" autocomplete="off">
                                </div>


                            

                                <div class="mb-3 text-center">
                                    <button type="button" name="submitlg" id="submitt" class="btn btn-primary  __ctm_btn border-radius-0 login_submit">Submit</button>
                                </div>
                            </form>



                        </div>


                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
@endsection

@push('script')
<script>
    $(document).ready(function () {
        $('#password').keypress(function (e) {
            var key = e.which;
            if (key == 13) {
                $('#submitt').click();
                return false;
            }
        });

        $('#submitt').click(function () {

            var form = new FormData();
            form.append('_token', CSRF_TOKEN);
            form.append('email_id', $("#email_id").val());
            form.append('password', $("#password").val());
            if (!validateEmail($('#email_id').val()) || $('#email_id').val() == "") {
                $('#email_id').css('border-color', 'red');
                $('#email_id').focus();
                return false;
            } else {
                $('#email_id').css('border-color', '');
            }
            if ($("#password").val() == "") {
                $("#password").focus();
                $("#password").css('border-color', 'red');
                return false;
            } else {
                $("#password").css('border-color', '');
            }
            var json = ajaxpost(form, "/sign-in");

            try {
                json = jQuery.parseJSON(json);
                alertSimple(json.message, json.status);
                if (json.status == true) {
                                          window.location = json.link;

                }
            } catch (e) {
                alert(e);
            }
        });
    });
</script>
@endpush
