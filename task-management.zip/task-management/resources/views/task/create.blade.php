@extends('layouts.app')
@section('title', 'Create Task')
@section('content')
<div id="page">
    <div class="content">
        <section class="wd100 section __signwrap">
            <div class="container">
                <div class="__signInerPG">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 login_box">
                            <span class="color-success"> </span>

                            <h3>Create new task</h3>
                            <input type="hidden" id="id" value="{{!empty($updateTask->id) ? $updateTask->id : ''}}">
                            <form method="post" onsubmit="return false;">

                                <div class="mb-3">
                                    <label for="exampleInputEmail1" id="labelHeading">Title</label><span class="required">*</span>
                                    <input type="text" class="form-control" value="{{!empty($updateTask->title) ? $updateTask->title : ''}}" required aria-describedby="Name" id="title">
                                </div>
                                <div class="mb-3">
                                    <label for="exampleInputEmail1" id="labelHeading">Description</label><span class="required">*</span>
                                    <textarea class="form-control" required aria-describedby="Name" id="description">{{!empty($updateTask->description) ? $updateTask->description : ''}}</textarea>
                                </div>
                                <div class="mb-2">
                                    <label for="exampleInputEmail1">Due Date</label><span class="required">*</span>
                                    <input type="text" class="form-control datepicker" value="{{!empty($updateTask->due_date) ? $updateTask->due_date : ''}}" readonly style="background: #fff;" aria-describedby="Name" id="due_date" autocomplete="off">
                                </div>

                                <div class="mb-3 text-center">
                                    <button type="button" onclick="createTask();" class="btn btn-primary  __ctm_btn border-radius-0 login_submit">Create Task <spinnerloader></spinnerloader></button>
                                </div>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
@endsection

@push('script')
<script>
    function createTask() {

        if ($('#title').val() == "") {
            $('#title').css('border-color', 'red');
            $('#title').focus();
            return false;
        } else {
            $('#title').css('border-color', '');
        }


        if ($('#description').val() == "") {
            $('#description').css('border-color', 'red');
            $('#description').focus();
            return false;
        } else {
            $('#description').css('border-color', '');
        }
        if ($('#due_date').val() == "") {
            $('#due_date').css('border-color', 'red');
            $('#due_date').focus();
            return false;
        } else {
            $('#due_date').css('border-color', '');
        }
        var form = new FormData();
        form.append('_token', CSRF_TOKEN);
        form.append('json[title]', $("#title").val());
        form.append('json[description]', $("#description").val());
        form.append('json[due_date]', $("#due_date").val());
        form.append('json[id]', $("#id").val());
        $('spinnerLoader').html('<i class="fas fa-spinner fa-spin"></i>');
        setTimeout(function () {
            kb();
        }, 500);
        function kb() {
            var json = ajaxpost(form, "/task/store");
            $('spinnerLoader').html('');
            try {
                json = jQuery.parseJSON(json);
                alertSimple(json.message, json.status);
                if (json.status == true) {
                    setTimeout(function () {
                        window.location = json.link_web;
                    }, 800);
                } else {

                }
            } catch (e) {
                alert(e);
            }
        }
    }
</script>
@endpush
