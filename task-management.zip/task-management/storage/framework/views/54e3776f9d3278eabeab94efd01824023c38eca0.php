<?php $__env->startSection('title', 'Task List'); ?>
<?php $__env->startSection('content'); ?>
<div id="page">
    <div class="content">
        <section class="wd100 section __signwrap">
            <div class="container">
                <div class="__signInerPG" style="max-width: inherit;">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 login_box">
                            <span class="color-success"> </span>

                            <h4>Welcome back! <?php echo e($user_name); ?></h4>
                            <h3>Task Management List</h3>
                            <div class="row">
                                <div class="col-sm-12" style="text-align: center;">
                                    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                        <a href="<?php echo e(url('task/create')); ?>"> <button type="button" class="btn btn-warning"><i class="fa fa-plus" aria-hidden="true"></i> Add New Task</button></a>
                                        <a href="<?php echo e(url('logout')); ?>"> <button type="button" class="btn btn-success"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</button></a>
                                    </div>
                                </div>
                                <div class="col-sm-12" style="text-align: center;">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">Title</th>
                                                <th scope="col">Status</th>
                                                <th scope="col">Description</th>
                                                <th scope="col">Due date</th>
                                                <th scope="col">Creation date</th>
                                                <th scope="col">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if(count($task)==0): ?>
                                            <tr>
                                                <th colspan="7">No task found.</th>
                                            </tr>
                                            <?php endif; ?>

                                            <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th scope="row"><?php echo e($key+1); ?></th>
                                                <td><?php echo e($d->title); ?></td>
                                                <td>
                                                    <input class="form-check-input" taskId="<?php echo e($d->id); ?>" <?php echo e(!empty($d->has_completed) ? 'checked' : ''); ?> onclick="markCompleted(this)" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e(empty($d->has_completed) ? 'Mark ' : ''); ?>Completed" type="checkbox" value="">
                                                </td>
                                                <td><?php echo e($d->description); ?></td>
                                                <td><?php echo e($d->due_date); ?></td>
                                                <td><?php echo e(date('Y-m-d h:i A',strtotime($d->created_at))); ?></td>
                                                <td>
                                                    <a href="<?php echo e(url("/task/update/$d->id")); ?>" ><span class="badge text-bg-primary"><i class="fas fa-edit"></i></span></a>
                                                    <a href="javascript::void(0)" onclick="deleteTask(<?php echo e($d->id); ?>);"><span class="badge text-bg-primary"><i class="fa fa-remove"></i></span></a>


                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>







                        </div>


                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<style>
    .badge{
        background-color: #a81d3f;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function () {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
            });
    });
    function deleteTask(taskId) {
        var form = new FormData();
        form.append('_token', CSRF_TOKEN);
        Swal.fire({
            title: "Are you sure want to delete your task ?",
            showCancelButton: true,
            inputLabel: 'Task Delete',
            confirmButtonText: 'Delete',
        }).then((result)=> {
            if (result.isConfirmed) {
                var json = ajaxpost(form, "/task/delete/"+taskId);
                try {
                    json = jQuery.parseJSON(json);
                    alertSimple(json.message, json.status);
                    if (json.status == true) {
                        setTimeout(function () {
                            location.reload();
                        }, 800)
                    }
                } catch (e) {
                    alert(e);
                }

            }
        });
    }
    function markCompleted(e) {
        var form = new FormData();
        var has_checked=$(e).is(':checked') ? 1 : 0;
        form.append('_token', CSRF_TOKEN);
        form.append('has_checked', has_checked);
        var taskId=$(e).attr('taskId');
        var json = ajaxpost(form, "/task/completed/"+taskId);
        try {
            json = jQuery.parseJSON(json);
            if (json.status == true) {
                $(e).attr('data-bs-original-title',has_checked==1 ?'Completed' : 'Mark Completed');
            }
        } catch (e) {
            alert(e);
        }
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp7.4\htdocs\task-management\resources\views/task/index.blade.php ENDPATH**/ ?>