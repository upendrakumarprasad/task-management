<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Task;

class TaskController extends Controller {

    public function index() {
        $tokenData = session()->get('signupAuth');
        $task = Task::where(['user_id' => $tokenData->id, 'deleted_at' => null])->orderBy('id', 'desc')->get();
        return view('task.index')->with(['task' => $task, 'user_name' => $tokenData->name]);
    }

    public function create($id = null) {
        $updateTask = Task::where(['id' => $id])->get()->first();
        return view('task.create')->with(['updateTask' => $updateTask]);
    }

    public function store(Request $request) {
        if (!empty($request['json']) && is_array($request['json'])) {
            $tokenData = session()->get('signupAuth');
            $json = $request['json'];
            $msg = "";
            if ($json['id'] > 0) {
                $json['updated_at'] = date('Y-m-d H:i:s');
                Task::where(['id' => $json['id']])->get()->first()->update($json);
                $msg = "Successfully updated";
            } else {
                $json['user_id'] = $tokenData->id;
                $json['due_date'] = date('Y-m-d', strtotime($json['due_date']));
                $json['created_at'] = date('Y-m-d H:i:s');
                Task::create($json);
                $msg = "Successfully created";
            }
            return response()->json(['status' => true, 'message' => $msg, 'link_web' => url('/')]);
        }
    }

    public function delete($id) {
        $json['deleted_at'] = date('Y-m-d H:i:s');
        Task::where(['id' => $id])->get()->first()->update($json);
        return response()->json(['status' => true, 'message' => "Successfully deleted"]);
    }

    public function completed(Request $request, $id) {
        $json['updated_at'] = date('Y-m-d H:i:s');
        $json['has_completed'] = $request['has_checked'];
        Task::where(['id' => $id])->get()->first()->update($json);
        return response()->json(['status' => true, 'message' => "Successfully completed"]);
    }

    public function taskCompletedRunJob() {
        $json['updated_at'] = date('Y-m-d H:i:s');
        $json['has_completed'] = 1;
        $myTask = Task::where(['has_completed' => 0])->get();
        foreach ($myTask as $key => $d) {
            Task::where(['id' => $d->id])->get()->first()->update($json);
        }
    }

}
