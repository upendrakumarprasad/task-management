<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Session;

class CustomAuth {

    /**
     * Handle an incoming request.
     * handel middle ware
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next) {
        $tokenData = session()->get('signupAuth');
       
        if (empty($tokenData->id)) {
            return redirect(url("/login"));
        }
        return $next($request);
    }

}
