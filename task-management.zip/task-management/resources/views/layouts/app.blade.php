<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <link rel="stylesheet" href="https://kikuuboonline.alwafaacloud.com/public/frontend-assets/css/bootstrap.css">
        <link rel="stylesheet" href="https://kikuuboonline.alwafaacloud.com/public/assets/css/style1.css">
        <link rel="stylesheet" href="https://code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">

        <script src="https://kit.fontawesome.com/9cea2b8228.js" crossorigin="anonymous"></script>

        <title>@yield('title')</title>

    </head>

    <body>
        <div class="container">
            @yield('content')
        </div>
    </body>

    <script>
        var base_url = '<?= url('/') ?>';
        var CSRF_TOKEN = "{{ csrf_token() }}";
    </script>
    <script src="https://kikuuboonline.alwafaacloud.com/public/frontend-assets/js/jquery.min.js"></script>
    <script src="https://kikuuboonline.alwafaacloud.com/public/frontend-assets/js/bootstrap.bundle.js"></script>  
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>

    <script>
        $(function () {
            $(".datepicker").datepicker({dateFormat: "yy-mm-dd"});
        });
        function ajaxpost(form, url) {
            var res = '';
            var xhr = new XMLHttpRequest();
            xhr.open('POST', base_url + url, false);
            xhr.onload = function () {
                res = xhr.responseText;
            };
            xhr.send(form);
            return res;
        }
        function validateEmail($email) {
            var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
            return emailReg.test($email);
        }
        function alertSimple(title, type, text = false) {
            Swal.fire({
                title: title,
                text: text,
                icon: type == true ? "success" : "error",
            });
        }
    </script>
    @stack('script')

</html>